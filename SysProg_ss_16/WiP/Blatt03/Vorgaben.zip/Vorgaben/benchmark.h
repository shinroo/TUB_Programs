
#include <stdlib.h>
#include "task.h"

#define NUM_TASKS 1024

def_task tasks[NUM_TASKS];

void createTasks();