#include "task.h"
//[LSG]
#include "benchmark.h"
//[/LSG]

void switch_task(int id)
{
	running_task = id;
}