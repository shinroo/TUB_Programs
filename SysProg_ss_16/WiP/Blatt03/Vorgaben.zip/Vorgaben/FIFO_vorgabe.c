#include "FIFO.h"
#include "task.h"
#include <stdlib.h>
#include <stdio.h>

static Queue *q;


int init_FIFO()
{

}

void free_FIFO()
{

}

void arrive_FIFO(int id, int length)
{

}

void tick_FIFO()
{

}

void finish_FIFO(int id)
{

}