#include "RR.h"
#include "task.h"
#include <stdlib.h>


int init_RR(int time_step)
{

}

void free_RR()
{

}

void arrive_RR(int id, int length)
{

}

void tick_RR()
{

}

void finish_RR(int id)
{

}
