SysProg SS16, Aufgabenblatt 1, Praxis Hausaufgabe 

Gruppenmitlgieder:

Hristo Filaretov
Robert Focke
Mikolaj Walukiewicz
