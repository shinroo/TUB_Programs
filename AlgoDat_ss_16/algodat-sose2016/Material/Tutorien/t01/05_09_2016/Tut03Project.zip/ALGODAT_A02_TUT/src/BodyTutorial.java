class BodyTutorial{
    public static void main(String [] args){
    	/* creates new tetrahedron */
        Body b = new Tetrahedron();
    } 
}
