public class Tetrahedron extends Body{
	
	private int length;
	
	/**
	 * Constructs tetrahedron with length 0
	 */
	protected Tetrahedron(){
		this.length = 0;
	}
	
	/**
	 * Constructs tetrahedron with length of @param length
	 */
	protected Tetrahedron(int length){
		this.length = length;
	}

	/**
	 * calculates Volume
	 */
	@Override
	double calculateVolume() {
		return Math.pow(this.length, 3) / (6 * Math.sqrt(2));
	}

	/**
	 * calculates Surface
	 */
	@Override
	double calculateSurface() {
		return Math.sqrt(3) * Math.pow(this.length, 2);
	}

}

