/**
 * Represents a geometrical 3d Body
 * @author AlgoDat
 *
 */
public abstract class Body{
	
	/*
	 * ----------------- Disclaimer ----------------- 
	 * abstract classes wont be able to become instantiated 
	 * all "abstract"-marked methods are only declared here
	 * "abstract"-marked methods assign the implementation...
	 * ... part to their subclasses.
	 */
	
	/**
	 * calculates the Volume of the body
	 * @return volume of body as double
	 */
	abstract double calculateVolume();
	
	/**
	 * calculates Surface of body
	 * @return surface of body as double
	 */
	abstract double calculateSurface();
	
}

